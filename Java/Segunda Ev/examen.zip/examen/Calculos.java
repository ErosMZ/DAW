import java.util.List;

public class Calculos extends InterfazUsuario{
    
    private String ref;
    private int metros3;

    public Calculos(String ref, int metros3){

        this.ref = ref;
        this.metros3= metros3;
        

    }

    
    
}

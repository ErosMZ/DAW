/////////////////////////////////////
//ESTE CODIGO NO SE PUEDE MODIFICAR//
/////////////////////////////////////

public class Tablon {
    public int largo;
    public int ancho;
    public int alto;
    public float precio;

    public Tablon (int largo, int ancho, int alto, float precio) {
        this.largo = largo;
        this.ancho = ancho;
        this.alto = alto;
        this.precio = precio;
    }

    
}







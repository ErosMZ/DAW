## Listado de tareas de DAW/DAM

En el siguiente fichero se detallarán las tareas  del equipo de desarrollo.  

### Antonio
    Inicializar repositorio
    Supervisar los pull requests de cada desarrollo

### Patxi

    Supervisar el desarrollo de la aplicación
    Asignar las tareas de desarrollo a cada integrante del equipo

### Ángel
    Configurar la infraestructura sobre la que se va a alojar la aplicación
    Supervisar las implementaciones críticas referentes a seguridad
### Javier Polit

### Javier García

    Diseño de la base de datos
    Normalización
    Implementación de la base de datos
    Preparar datos de prueba

### Chat GPT
    Resolver dudas del equipo técnico
    Mejorar la calidad del código en funciones de alta complejidad